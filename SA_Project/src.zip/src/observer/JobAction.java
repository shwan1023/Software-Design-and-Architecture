package observer;

public enum JobAction {
    START, STOP
}
