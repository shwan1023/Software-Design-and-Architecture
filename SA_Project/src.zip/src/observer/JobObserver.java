package observer;

public interface JobObserver {
    void update(Job job);
}
