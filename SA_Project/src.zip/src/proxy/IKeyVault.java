package proxy;

public interface IKeyVault {
    String getSecret(String key);
}
