package utility;

public class AzureMonitor {
    public void logTraffic(String data) {
        System.out.println("Azure Monitor日志记录: " + data);
    }
}
