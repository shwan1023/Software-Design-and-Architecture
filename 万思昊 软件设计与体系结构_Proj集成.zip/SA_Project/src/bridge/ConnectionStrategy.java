package bridge;

public interface ConnectionStrategy {
    void execute();
}
