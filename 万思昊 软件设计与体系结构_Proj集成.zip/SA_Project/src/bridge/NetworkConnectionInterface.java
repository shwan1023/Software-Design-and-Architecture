package bridge;

public interface NetworkConnectionInterface {
    void executeConnection();
}
