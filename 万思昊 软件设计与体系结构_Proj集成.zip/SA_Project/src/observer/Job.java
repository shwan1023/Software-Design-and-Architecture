package observer;

public class Job {
    private String jobDetails;

    public Job(String jobDetails) {
        this.jobDetails = jobDetails;
    }

    public String getJobDetails() {
        return jobDetails;
    }
}
