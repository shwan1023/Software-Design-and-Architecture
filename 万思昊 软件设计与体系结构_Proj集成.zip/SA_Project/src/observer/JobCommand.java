package observer;

public interface JobCommand {
    void execute(Job job);
}
