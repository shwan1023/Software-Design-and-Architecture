package utility;

public class DNSComponent {
    public void resolve(String domain) {
        System.out.println("DNS解析: " + domain);
    }
}
