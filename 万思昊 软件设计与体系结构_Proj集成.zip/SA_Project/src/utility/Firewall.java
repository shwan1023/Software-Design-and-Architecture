package utility;

public class Firewall {
    public void filterTraffic(String trafficSource) {
        System.out.println("防火墙筛选来自 " + trafficSource + " 的流量");
        // 流量筛选逻辑
    }

    // 添加流量监控方法
    public void monitorTraffic() {
        System.out.println("监控网络流量");
        // 流量监控逻辑
    }
}

